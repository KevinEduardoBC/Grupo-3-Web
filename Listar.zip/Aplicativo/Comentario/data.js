module.exports = function () {
  var data = {
    comentarios: [
      {
        id:1,
        name: "Daniel",
        fecha: "2013-09-10",
        publicacion:"se reporto su desaparicion el viernes pasado en san miguel",
      },
      {
        id:2,
        name: "Juan",
        fecha: "2010-10-10",
        publicacion:"gfhjgjwegqewrrw",
      },
      {
        id:3,
        name: "Rodrigo",
        fecha: "2022-06-05",
        publicacion:"jsagdjiasgdiasdsa",
      },
      {
        id:4,
        name: "Susana",
        fecha: "2021-09-10",
        publicacion:"asjdguasdkada",
	}
    ],
  }
  return data
}
