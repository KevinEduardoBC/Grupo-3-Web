export const environments={
  production:false,
  base:"http://localhost:5000"
}
