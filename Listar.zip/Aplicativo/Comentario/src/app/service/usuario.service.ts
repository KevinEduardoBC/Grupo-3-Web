import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environments } from 'src/environments/environments';
import { Usuario } from '../model/usuario';
const base_url=environments.base
@Injectable({
  providedIn: 'root'
})
export class UsuarioService {
private url=`${base_url}/comentarios`
  constructor(private http:HttpClient) { }
  List(){
    return this.http.get<Usuario[]>(this.url);

  }


}
