import { Component, OnInit } from '@angular/core';
import { Usuario } from 'src/app/model/usuario';
import { MatTableDataSource } from '@angular/material/table'
import { UsuarioService } from 'src/app/service/usuario.service';

@Component({
  selector: 'app-usuario-listar',
  templateUrl: './usuario-listar.component.html',
  styleUrls: ['./usuario-listar.component.css']
})
export class UsuarioListarComponent implements OnInit{

  Lista: Usuario[]=[]

  dataSource:MatTableDataSource<Usuario>=new MatTableDataSource();
  displayedColumns:string[]=['codigo','nombre','fecha','publicacion']
  constructor(private aS:UsuarioService){

  }
  ngOnInit(): void {
    this.aS.List().subscribe(data=>{
      this.dataSource=new MatTableDataSource(data);
    })
  }

}
