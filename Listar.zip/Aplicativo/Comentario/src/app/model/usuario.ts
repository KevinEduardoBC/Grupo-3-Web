export class Usuario {
  id: number = 0;
  name: string = '';
  fecha: Date = new Date(Date.now());
  publicacion: string = '';
}
